        <hr>
            </div>
    <!-- /.container -->
        <!-- Footer -->
        <footer>
            <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p>Desarrollado por <a href="mailto:luxohcf@gmail.com?subject=Contacto GoPucon" target="_blank">Luxo Lizama</a> - 2014
                    </p>
                    <p>Construido con <a href="http://getbootstrap.com">Bootstrap</a> Versión v3.2.0
                        y <a href="http://jquery.com/">jQuery</a> Versión 1.11.0
                    </p>
                </div>
            </div>
            </div>
        </footer>

    </div>
</body>
</html>